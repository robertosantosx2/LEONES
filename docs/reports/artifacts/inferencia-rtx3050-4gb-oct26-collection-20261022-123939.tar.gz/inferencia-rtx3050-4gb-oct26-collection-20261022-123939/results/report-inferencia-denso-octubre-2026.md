# Informe de inferencia — Octubre de 2026

## Alcance

Resultados locales recogidos el 22 de octubre de 2026. Se conservan los
experimentos por motor, sin tratar modelos y protocolos distintos como una
comparación directa de rendimiento.

## Experimento A — llama.cpp

- Modelo: Qwen3-30B-A3B-Instruct-2507 IQ3_XXS
- Prueba: `llama-bench`, pp128 y tg32
- Capas GPU: 0, 1 y 8; tres repeticiones por configuración
- Estado: nueve ejecuciones completadas con código 0
- Informe detallado: [`benchmark-report.md`](layer-sweep-20261022-115737/benchmark-report.md)
- Estadísticas: [`statistics.csv`](layer-sweep-20261022-115737/statistics.csv)
- Mediciones: [`measurements.csv`](layer-sweep-20261022-115737/measurements.csv)

### Resumen de llama.cpp

| Capas GPU | Prueba | Media tok/s | Mediana tok/s | Desv. estándar |
|---:|---|---:|---:|---:|
| 0 | pp128 | 22.553 | 24.42 | 8.093 |
| 0 | tg32 | 1.487 | 1.45 | 0.1 |
| 1 | pp128 | 74.473 | 76.25 | 16.377 |
| 1 | tg32 | 1.66 | 1.44 | 0.416 |
| 8 | pp128 | 34.957 | 26.38 | 30.746 |
| 8 | tg32 | 1.827 | 1.88 | 0.157 |

## Experimento B — TensorFold

- Modelo: Qwen3.5-2B MLX-4bit
- Backend: CUDA
- Prueba: cinco peticiones API secuenciales; 66 tokens de entrada y 128 de salida
- Estado: 5/5 respuestas HTTP 200
- Informe detallado: [`tensorfold-qwen35-2b-4bit-20261022-121705/benchmark-report.md`](tensorfold-qwen35-2b-4bit-20261022-121705/benchmark-report.md)
- Mediciones: [`tensorfold-qwen35-2b-4bit-20261022-121705/measurements.csv`](tensorfold-qwen35-2b-4bit-20261022-121705/measurements.csv)
- Respuestas originales: [`responses/`](tensorfold-qwen35-2b-4bit-20261022-121705/responses/)

## Interpretación

Los resultados de llama.cpp y TensorFold se mantienen separados. Qwen3-30B-A3B
IQ3_XXS y Qwen3.5-2B MLX-4bit son modelos diferentes, y `llama-bench` no mide
lo mismo que las peticiones API de TensorFold. No se debe inferir que un motor
es superior al otro a partir de las cifras brutas de tok/s.

Para una comparación más rigurosa, hacen falta tareas equivalentes, longitudes
de entrada y salida controladas, varias repeticiones, medición de memoria y
GPU durante la ejecución, y evaluación separada de la calidad.
