# Benchmark de capas GPU — Qwen3-30B-A3B IQ3_XXS

## Entorno y configuración

- Motor: llama.cpp / `llama-bench`
- Build: `6fa4f6cd3 (11740)`
- Modelo: `Qwen_Qwen3-30B-A3B-Instruct-2507-IQ3_XXS.gguf`
- Tamaño informado por llama-bench: 11.37 GiB
- Hilos: 8
- Prompt: 128 tokens (`pp128`)
- Generación: 32 tokens (`tg32`)
- Configuraciones: 0, 1 y 8 capas GPU
- Repeticiones por configuración: 3
- Ejecuciones: 9; todas finalizaron con código 0.

## Resumen estadístico

| Capas GPU | Prueba | N | Media tok/s | Mediana tok/s | Desviación estándar | Mínimo | Máximo |
|---:|---|---:|---:|---:|---:|---:|---:|
| 0 | pp128 | 3 | 22.553 | 24.42 | 8.093 | 13.69 | 29.55 |
| 0 | tg32 | 3 | 1.487 | 1.45 | 0.1 | 1.41 | 1.6 |
| 1 | pp128 | 3 | 74.473 | 76.25 | 16.377 | 57.28 | 89.89 |
| 1 | tg32 | 3 | 1.66 | 1.44 | 0.416 | 1.4 | 2.14 |
| 8 | pp128 | 3 | 34.957 | 26.38 | 30.746 | 9.41 | 69.08 |
| 8 | tg32 | 3 | 1.827 | 1.88 | 0.157 | 1.65 | 1.95 |

## Resultados individuales

| Capas GPU | Repetición | Prueba | tok/s | Log |
|---:|---:|---|---:|---|
| 0 | 1 | pp128 | 13.69 | [`ngl0-rep1.log`](ngl0-rep1.log) |
| 0 | 1 | tg32 | 1.45 | [`ngl0-rep1.log`](ngl0-rep1.log) |
| 0 | 2 | pp128 | 24.42 | [`ngl0-rep2.log`](ngl0-rep2.log) |
| 0 | 2 | tg32 | 1.41 | [`ngl0-rep2.log`](ngl0-rep2.log) |
| 0 | 3 | pp128 | 29.55 | [`ngl0-rep3.log`](ngl0-rep3.log) |
| 0 | 3 | tg32 | 1.6 | [`ngl0-rep3.log`](ngl0-rep3.log) |
| 1 | 1 | pp128 | 57.28 | [`ngl1-rep1.log`](ngl1-rep1.log) |
| 1 | 1 | tg32 | 1.44 | [`ngl1-rep1.log`](ngl1-rep1.log) |
| 1 | 2 | pp128 | 76.25 | [`ngl1-rep2.log`](ngl1-rep2.log) |
| 1 | 2 | tg32 | 1.4 | [`ngl1-rep2.log`](ngl1-rep2.log) |
| 1 | 3 | pp128 | 89.89 | [`ngl1-rep3.log`](ngl1-rep3.log) |
| 1 | 3 | tg32 | 2.14 | [`ngl1-rep3.log`](ngl1-rep3.log) |
| 8 | 1 | pp128 | 69.08 | [`ngl8-rep1.log`](ngl8-rep1.log) |
| 8 | 1 | tg32 | 1.88 | [`ngl8-rep1.log`](ngl8-rep1.log) |
| 8 | 2 | pp128 | 26.38 | [`ngl8-rep2.log`](ngl8-rep2.log) |
| 8 | 2 | tg32 | 1.65 | [`ngl8-rep2.log`](ngl8-rep2.log) |
| 8 | 3 | pp128 | 9.41 | [`ngl8-rep3.log`](ngl8-rep3.log) |
| 8 | 3 | tg32 | 1.95 | [`ngl8-rep3.log`](ngl8-rep3.log) |

## Interpretación y limitaciones

- Una capa GPU obtuvo la mayor mediana de prefill en esta serie.
- Ocho capas tuvo una dispersión elevada en prefill; hacen falta pruebas
  controladas antes de atribuirla a la configuración.
- La velocidad de prefill y la de generación son métricas distintas.
- La medición de utilización de GPU se realizó después de cada ejecución,
  no durante ella; por tanto, no caracteriza la utilización máxima.
- Estos resultados corresponden a este equipo, build, modelo y parámetros.
- No son directamente comparables con TensorFold/Qwen3.5-2B-MLX-4bit:
  es otro modelo, formato y protocolo de inferencia.
- La comparación entre motores debe mantener separadas las métricas
  específicas de cada motor y registrar las condiciones de ejecución.
