# Benchmark TensorFold — Qwen3.5-2B MLX-4bit

## Entorno y protocolo

- Motor: TensorFold 1.1.1
- Modelo: `mlx-community/Qwen3.5-2B-MLX-4bit`
- Backend: CUDA; GPU NVIDIA RTX 3050 Laptop, compute capability sm_86
- Servidor: contexto 2048, paralelismo 1, thinking desactivado
- Peticiones: 5, secuenciales, temperatura 0, máximo 128 tokens
- Prompt: evaluación de un modelo local, en español
- Respuestas: HTTP 200 en las cinco ejecuciones
- Entrada por petición: 66 tokens; salida: 128 tokens
- Datos originales: `measurements.csv` y `responses/run-*.json`
- Entorno capturado en `environment.txt`; configuración en `config.txt`
- `server.log` se conserva si el script inició el servidor.

## Resumen estadístico

Las velocidades y tiempos siguientes son los reportados por el servidor o
medidos por el cliente, según la columna. Los tiempos están expresados en
segundos; la velocidad, en tokens por segundo.

| Métrica | Media | Mediana | Mínimo | Máximo |
|---|---:|---:|---:|---:|
| Velocidad reportada (tok/s) | 105.42070 | 106.45479 | 103.40711 | 107.06838 |
| Tiempo HTTP cliente (s) | 1.28808 | 1.28076 | 1.24923 | 1.31740 |
| TTFT reportado (s) | 0.07796 | 0.08465 | 0.05106 | 0.08493 |
| Prefill reportado (s) | 0.07414 | 0.08044 | 0.04893 | 0.08049 |

## Resultados por ejecución

| Run | HTTP | Entrada | Salida | Velocidad tok/s | Tiempo cliente s | TTFT s | Prefill s | Hash salida |
|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 1 | 200 | 66 | 128 | 107.068 | 1.249 | 0.05106 | 0.04893 | `942ca6d9de584e12bd4f207d8cafddcffb594924f5d781501b267b7a1ca9ddad` |
| 2 | 200 | 66 | 128 | 103.407 | 1.317 | 0.08445 | 0.08044 | `942ca6d9de584e12bd4f207d8cafddcffb594924f5d781501b267b7a1ca9ddad` |
| 3 | 200 | 66 | 128 | 106.496 | 1.280 | 0.08465 | 0.08049 | `942ca6d9de584e12bd4f207d8cafddcffb594924f5d781501b267b7a1ca9ddad` |
| 4 | 200 | 66 | 128 | 103.677 | 1.313 | 0.08493 | 0.08044 | `942ca6d9de584e12bd4f207d8cafddcffb594924f5d781501b267b7a1ca9ddad` |
| 5 | 200 | 66 | 128 | 106.455 | 1.281 | 0.08470 | 0.08041 | `942ca6d9de584e12bd4f207d8cafddcffb594924f5d781501b267b7a1ca9ddad` |

## Reproducibilidad y limitaciones

- Hashes distintos de salida: 1.
- Las cinco respuestas alcanzaron el límite de 128 tokens; el texto puede estar truncado por el límite de generación.
- La latencia cliente mide el ciclo HTTP completo, no solo la generación del modelo.
- La medición de GPU guardada al final no equivale a una medición de utilización máxima durante cada petición.
- No existe una equivalencia directa entre las capas GPU de llama.cpp y un ajuste de TensorFold; no se ha simulado ese barrido.
- Este resultado caracteriza esta máquina, versión, modelo, prompt y configuración; no permite comparar calidad entre modelos.
