#!/usr/bin/env bash
set -uo pipefail

OUT="$HOME/benchmarks/qwen3-30b-a3b-iq3-xxs"
LLAMA="$HOME/llama.cpp-cuda/build-cuda/bin/llama-bench"
MODEL="$OUT/Qwen_Qwen3-30B-A3B-Instruct-2507-IQ3_XXS.gguf"
DIR="$OUT/layer-sweep-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DIR"

[[ -x "$LLAMA" ]] || { echo "ERROR: no existe llama-bench: $LLAMA"; exit 1; }
[[ -f "$MODEL" ]] || { echo "ERROR: no existe el modelo: $MODEL"; exit 1; }

printf 'layers\trepetition\texit_code\tlog\n' > "$DIR/summary.tsv"
{
  date --iso-8601=seconds
  "$LLAMA" --version
  sha256sum "$MODEL"
  free -h
  nvidia-smi
} > "$DIR/metadata.txt" 2>&1

for LAYERS in 0 1 8; do
  for REP in 1 2 3; do
    LOG="$DIR/ngl${LAYERS}-rep${REP}.log"
    echo "===== N_GPU_LAYERS=$LAYERS, repetición $REP/3 ====="

    set +e
    "$LLAMA" \
      --model "$MODEL" \
      --n-gpu-layers "$LAYERS" \
      --n-prompt 128 \
      --n-gen 32 \
      --repetitions 1 \
      --threads 8 > "$LOG" 2>&1
    RC=$?
    set -e

    printf '%s\t%s\t%s\t%s\n' "$LAYERS" "$REP" "$RC" "$LOG" \
      >> "$DIR/summary.tsv"

    tail -25 "$LOG"
    echo "Código de salida: $RC"
    free -h
    nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu \
      --format=csv,noheader 2>/dev/null || true
    sleep 5
  done
done

echo "Fin: $(date --iso-8601=seconds)" >> "$DIR/metadata.txt"
echo "Resultados completos: $DIR"
cat "$DIR/summary.tsv"
