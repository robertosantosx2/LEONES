#!/usr/bin/env bash
set -Eeuo pipefail

BASE="$HOME/benchmarks/qwen3-30b-a3b-iq3-xxs"
TF="$HOME/.local/opt/tensorfold-1.1.1-linux-x86_64/bin/tensorfold-native"
MODEL="mlx-community/Qwen3.5-2B-MLX-4bit"
HOST="127.0.0.1"
PORT="8080"
API="http://${HOST}:${PORT}/v1/chat/completions"
HEALTH="http://${HOST}:${PORT}/health"
REPS=5

STAMP="$(date +%Y%m%d-%H%M%S)"
DIR="$BASE/tensorfold-qwen35-2b-4bit-$STAMP"
mkdir -p "$DIR/responses"
SERVER_PID=""
STARTED_SERVER=0

cleanup() {
    if [[ "$STARTED_SERVER" == 1 && -n "$SERVER_PID" ]]; then
        kill -TERM "$SERVER_PID" 2>/dev/null || true
        for _ in $(seq 1 30); do
            kill -0 "$SERVER_PID" 2>/dev/null || break
            sleep 1
        done
        kill -0 "$SERVER_PID" 2>/dev/null && kill -KILL "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
    fi
}
trap cleanup EXIT

if [[ ! -x "$TF" ]]; then
    echo "ERROR: no encuentro el binario: $TF" >&2
    exit 1
fi

cat > "$DIR/config.txt" <<EOF
Fecha: $(date --iso-8601=seconds)
Motor: TensorFold 1.1.1
Modelo: $MODEL
Backend: CUDA
API: $API
Repeticiones: $REPS
Temperatura: 0
Max tokens: 128
Contexto del servidor: 2048
Paralelismo del servidor: 1
Thinking: desactivado
EOF

{
    echo "===== SISTEMA ====="
    uname -a
    echo
    free -h
    echo
    df -h "$HOME"
    echo
    nvidia-smi
    echo
    echo "===== VERSIÓN TENSORFOLD ====="
    "$TF" --version 2>&1 || true
} > "$DIR/environment.txt"

# Comprueba si ya hay un servidor respondiendo.
if ! python3 - "$HEALTH" <<'PY'
import sys, urllib.request
try:
    with urllib.request.urlopen(sys.argv[1], timeout=2) as r:
        sys.exit(0 if r.status == 200 else 1)
except Exception:
    sys.exit(1)
PY
then
    echo "Iniciando TensorFold CUDA..."
    TENSORFOLD_NO_UPDATE_CHECK=1 "$TF" serve \
        "$MODEL" \
        --backend cuda \
        --name qwen35-2b-4bit \
        --host "$HOST" \
        --port "$PORT" \
        --context 2048 \
        --parallel 1 \
        --max-tokens 128 \
        --no-thinking \
        --no-update-check \
        > "$DIR/server.log" 2>&1 &
    SERVER_PID=$!
    STARTED_SERVER=1

    READY=0
    for _ in $(seq 1 90); do
        if python3 - "$HEALTH" <<'PY'
import sys, urllib.request
try:
    with urllib.request.urlopen(sys.argv[1], timeout=2) as r:
        sys.exit(0 if r.status == 200 else 1)
except Exception:
    sys.exit(1)
PY
        then
            READY=1
            break
        fi
        if ! kill -0 "$SERVER_PID" 2>/dev/null; then
            echo "ERROR: TensorFold terminó durante el arranque." >&2
            tail -80 "$DIR/server.log" >&2 || true
            exit 1
        fi
        sleep 2
    done

    if [[ "$READY" != 1 ]]; then
        echo "ERROR: TensorFold no respondió en 180 segundos." >&2
        tail -80 "$DIR/server.log" >&2 || true
        exit 1
    fi
fi

echo "Servidor disponible. Resultados en: $DIR"

# Ejecuta las peticiones en serie y guarda cada respuesta sin perder campos.
python3 - "$API" "$DIR" "$REPS" <<'PY'
import csv, json, os, sys, time, urllib.request, urllib.error, hashlib

api, directory, repetitions = sys.argv[1], sys.argv[2], int(sys.argv[3])
response_dir = os.path.join(directory, "responses")
os.makedirs(response_dir, exist_ok=True)

prompt = (
    "Responde en español. Explica en una lista numerada de 8 puntos "
    "cómo evaluar un modelo de lenguaje local, incluyendo latencia, "
    "prefill, velocidad de generación, memoria, calidad y reproducibilidad. "
    "Cada punto debe contener una explicación breve y concreta."
)

rows = []
for run in range(1, repetitions + 1):
    filename = f"run-{run:02d}.json"
    path = os.path.join(response_dir, filename)
    payload = {
        "model": "qwen35-2b-4bit",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 128,
        "stream": False,
        "enable_thinking": False
    }
    req = urllib.request.Request(
        api,
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    start = time.perf_counter()
    status, raw, error = None, b"", ""
    try:
        with urllib.request.urlopen(req, timeout=600) as response:
            status = response.status
            raw = response.read()
    except Exception as exc:
        error = repr(exc)
        if isinstance(exc, urllib.error.HTTPError):
            status = exc.code
            raw = exc.read()
    elapsed = time.perf_counter() - start

    try:
        data = json.loads(raw.decode("utf-8", errors="replace")) if raw else {}
    except Exception:
        data = {"raw_response": raw.decode("utf-8", errors="replace")}

    record = {
        "run": run,
        "http_status": status,
        "wall_seconds_client": round(elapsed, 6),
        "client_error": error or None,
        "response": data
    }
    with open(path, "w") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)

    # Busca métricas aunque el servidor las anide en objetos diferentes.
    flat = {}
    def walk(obj, prefix=""):
        if isinstance(obj, dict):
            for k, v in obj.items():
                key = f"{prefix}.{k}" if prefix else k
                if isinstance(v, (dict, list)):
                    walk(v, key)
                else:
                    flat[key.lower()] = v
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                walk(v, f"{prefix}[{i}]")

    walk(data)

    def metric(*names):
        for name in names:
            for key, value in flat.items():
                if key == name.lower() or key.endswith("." + name.lower()):
                    return value
        return ""

    text = ""
    try:
        text = data["choices"][0]["message"].get("content", "") or ""
    except Exception:
        pass

    usage = data.get("usage", {}) if isinstance(data, dict) else {}
    rows.append({
        "run": run,
        "http_status": status if status is not None else "",
        "wall_seconds_client": round(elapsed, 6),
        "prompt_tokens": usage.get("prompt_tokens", ""),
        "completion_tokens": usage.get("completion_tokens", ""),
        "total_tokens": usage.get("total_tokens", ""),
        "tokens_per_second_reported": metric("tokens_per_second", "tokens_per_sec", "generation_tokens_per_second"),
        "seconds_reported": metric("seconds", "generation_seconds"),
        "prefill_seconds": metric("prefill_seconds", "prefill_time"),
        "time_to_first_token": metric("time_to_first_token", "ttft"),
        "drafts_enabled": metric("drafts", "speculative_drafts"),
        "drafted_tokens": metric("drafted", "drafted_tokens"),
        "accepted_tokens": metric("accepted", "accepted_tokens"),
        "acceptance_rate": metric("acceptance_rate", "speculative_acceptance_rate"),
        "output_chars": len(text),
        "output_sha256": hashlib.sha256(text.encode()).hexdigest() if text else "",
        "response_json": filename,
        "error": error
    })
    print(
        f"Run {run}/{repetitions}: HTTP={status} "
        f"wall={elapsed:.3f}s completion_tokens={usage.get('completion_tokens', '?')} "
        f"reported_tok_s={metric('tokens_per_second', 'tokens_per_sec')}"
    )
    time.sleep(2)

csv_path = os.path.join(directory, "measurements.csv")
fields = list(rows[0].keys()) if rows else []
with open(csv_path, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)

with open(os.path.join(directory, "summary.txt"), "w") as f:
    f.write(f"Repeticiones: {len(rows)}\n")
    f.write(f"HTTP 200: {sum(str(r['http_status']) == '200' for r in rows)}\n")
    f.write("La latencia cliente incluye el tiempo de respuesta HTTP completo.\n")
    f.write("Las métricas del motor quedan vacías si la respuesta no las incluye.\n")

print(f"\nCSV: {csv_path}")
print(f"Respuestas JSON: {response_dir}")
PY

{
    echo "===== ESTADO GPU DESPUÉS ====="
    nvidia-smi
    echo
    echo "===== MEMORIA DESPUÉS ====="
    free -h
} > "$DIR/after.txt"

echo
echo "===== RESULTADOS ====="
cat "$DIR/summary.txt"
column -s, -t "$DIR/measurements.csv" 2>/dev/null || cat "$DIR/measurements.csv"
echo
echo "Directorio de resultados: $DIR"
