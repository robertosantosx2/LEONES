#!/usr/bin/env bash
# DESCARTED_ENGINES: SGLang
# DESCARTED_ENGINES: KTransformers
# SGLang: Qwen3.5-4B aparece soportado en formato Hugging Face.
# No se ha demostrado compatibilidad directa con nuestro GGUF Q4_K_M.
# Entorno Python 3.12 creado; dry-run realizado, NO instalado ni ejecutado.
# Antes de instalar: verificar cuantización, memoria y ruta de carga viable.
# KTransformers: rama qwen3.5 clonada en ~/ktransformers.
# La guía examinada se centra en Qwen3.5 MoE-400B y hardware multinodo.
# No compilar ni ejecutar esa integración para este equipo sin una ruta
# específica y verificable para Qwen3.5-4B.
# vLLM: excluido de esta batería; no hubo inferencia válida.
# SGLang: entorno Python 3.12 creado; resolución dry-run correcta;
# todavía NO instalado ni ejecutado. Verificar soporte para Qwen3.5-4B
# y formato compatible antes de instalar dependencias CUDA.
# KTransformers: rama qwen3.5 clonada en ~/ktransformers.
# La guía revisada se dirige a Qwen3.5 MoE-400B (4x RTX 4090 y 800GB RAM).
# No compilar ni ejecutar esa integración en este equipo sin identificar
# una ruta compatible con Qwen3.5-4B y sus requisitos reales.
DISCARDED_ENGINES=("SGLang" "KTransformers")
PENDING_ENGINES=()
printf "[DESCARTADO] Motores excluidos: %s\n" "${DISCARDED_ENGINES[*]}"
printf "[PENDIENTES] Motores por preparar: %s\n" "${PENDING_ENGINES[*]}"

# Reproducible, sequential Qwen3.5-4B benchmark:
# Mistral.rs, TensorFold MLX-4bit, llama.cpp CUDA GGUF Q4_K_M y RustingStrata.
# Does not edit ODS .env or Compose files.
set -Eeuo pipefail

TF="${HOME}/tensorfold-test/tensorfold-1.1.1-linux-x86_64/bin/tensorfold-native"
LLAMA="${HOME}/llama.cpp-cuda/build-cuda/bin/llama-server"
STRATA="${HOME}/rusting-strata-test/target/release/strata"
MISTRAL="${HOME}/.local/bin/mistralrs"
GGUF="${HOME}/llama.cpp-cuda/models/qwen3.5-4b-Q4_K_M.gguf"
TF_MODEL="mlx-community/Qwen3.5-4B-MLX-4bit"
TF_PORT=18084
LLAMA_PORT=18085
STRATA_PORT=18086
MISTRAL_PORT=18087
CTX=256
MAX_TOKENS=32
RUNS=3
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="${HOME}/qwen35-4b-benchmark-fixed-${STAMP}"
PROMPT="Responde en español en una sola frase: ¿qué ventajas tiene ejecutar una IA local?"

mkdir -p "$OUT"
exec > >(tee -a "$OUT/benchmark.log") 2>&1

log() { printf '[%s] %s\n' "$(date '+%F %T')" "$*"; }
fail() { log "ERROR: $*"; exit 1; }

for f in "$TF" "$LLAMA" "$STRATA" "$MISTRAL" "$GGUF"; do
  [[ -e "$f" ]] || fail "No encuentro: $f"
done
command -v python3 >/dev/null || fail "Falta python3"
command -v curl >/dev/null || fail "Falta curl"

# Refuse to accidentally benchmark against unrelated servers already on our ports.
for port in "$TF_PORT" "$LLAMA_PORT" "$STRATA_PORT" "$MISTRAL_PORT"; do
  if curl --silent --show-error --max-time 1 "http://127.0.0.1:${port}/v1/models" >/dev/null 2>&1; then
    fail "El puerto ${port} ya tiene un servidor activo. Detén el proceso que lo usa y vuelve a ejecutar."
  fi
done

PIDS=()
cleanup() {
  local pid
  for pid in "${PIDS[@]:-}"; do
    kill "$pid" 2>/dev/null || true
  done
  for pid in "${PIDS[@]:-}"; do
    wait "$pid" 2>/dev/null || true
  done
  log "Servidores iniciados por este script detenidos."
}
trap cleanup EXIT INT TERM

cat > "$OUT/environment.txt" <<EOF
date=$(date --iso-8601=seconds)
host=$(hostname)
kernel=$(uname -srmo)
gpu=$(nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>/dev/null | head -1 || true)
context=$CTX
max_tokens=$MAX_TOKENS
runs=$RUNS
prompt=$PROMPT
TensorFold quantization=MLX-4bit
llama.cpp/RustingStrata quantization=GGUF Q4_K_M
Note=Practical comparison, quantizations differ; engines run sequentially.
RustingStrata=uses isolated CUDA 13.0 NVRTC and cache to avoid unsupported PTX from system NVRTC.
Mistral.rs=GGUF Q4_K_M; placement can span GPU and CPU.
llama.cpp=explicit 99 GPU layers, matching the previously verified CUDA run rather than conservative auto placement.
EOF

# Client uses non-streaming JSON consistently. It captures both OpenAI-compatible
# content and engine timing metadata, avoiding the previous empty-SSE-delta bug.
cat > "$OUT/client.py" <<'PY'
import json, sys, time, urllib.request, urllib.error

engine, url, model, prompt, max_tokens, run_no, output_path = sys.argv[1:]
payload = {
    "model": model,
    "messages": [{"role": "user", "content": prompt}],
    "max_tokens": int(max_tokens),
    "temperature": 0,
    "stream": False,
}
if engine == "mistral_rs":
    payload["chat_template_kwargs"] = {"enable_thinking": False}
request = urllib.request.Request(
    url,
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST",
)
start = time.perf_counter()
status = 0
raw = b""
error = ""
try:
    with urllib.request.urlopen(request, timeout=180) as response:
        status = response.status
        raw = response.read()
except Exception as exc:
    error = str(exc)
wall = time.perf_counter() - start
content = ""
completion_tokens = None
prompt_tokens = None
server_tps = None
prefill_tps = None
ttft = None
finish_reason = ""
metadata = {}
try:
    data = json.loads(raw.decode("utf-8", "replace"))
    choice = (data.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    content = message.get("content") or ""
    # Some templates may return an array of text blocks.
    if isinstance(content, list):
        content = "".join(
            x.get("text", "") if isinstance(x, dict) else str(x) for x in content
        )
    finish_reason = choice.get("finish_reason", "")
    usage = data.get("usage") or {}
    completion_tokens = usage.get("completion_tokens")
    prompt_tokens = usage.get("prompt_tokens")
    if engine == "mistral_rs":
        for key in (
            "avg_compl_tok_per_sec", "avg_prompt_tok_per_sec",
            "avg_tok_per_sec", "total_completion_time_sec",
            "total_prompt_time_sec", "total_time_sec",
        ):
            if usage.get(key) is not None:
                metadata["mistral_" + key] = usage[key]
        server_tps = usage.get("avg_compl_tok_per_sec")
        prefill_tps = usage.get("avg_prompt_tok_per_sec")
    tfmeta = data.get("tensorfold") or {}
    if tfmeta:
        server_tps = tfmeta.get("tokens_per_second")
        prefill_seconds = tfmeta.get("prefill_seconds")
        if prefill_seconds and prompt_tokens:
            prefill_tps = prompt_tokens / prefill_seconds
        ttft = tfmeta.get("time_to_first_token")
    timings = data.get("timings") or {}
    if timings:
        predicted_n = timings.get("predicted_n")
        predicted_ms = timings.get("predicted_ms")
        prompt_n = timings.get("prompt_n")
        prompt_ms = timings.get("prompt_ms")
        if predicted_n and predicted_ms:
            server_tps = predicted_n * 1000.0 / predicted_ms
        if prompt_n and prompt_ms:
            prefill_tps = prompt_n * 1000.0 / prompt_ms
        if prompt_ms is not None:
            metadata["llama_prompt_ms"] = prompt_ms
        if predicted_ms is not None:
            metadata["llama_predicted_ms"] = predicted_ms
    if completion_tokens is None and server_tps and wall:
        completion_tokens = round(server_tps * wall)
except Exception as exc:
    error = (error + "; " if error else "") + "JSON parse: " + str(exc)

record = {
    "engine": engine,
    "run": int(run_no),
    "http_status": status,
    "wall_seconds": round(wall, 4),
    "ttft_seconds": round(ttft, 4) if isinstance(ttft, (int, float)) else None,
    "prompt_tokens": prompt_tokens,
    "completion_tokens": completion_tokens,
    "tokens_per_second": round(server_tps, 3) if isinstance(server_tps, (int, float)) else None,
    "prefill_tokens_per_second": round(prefill_tps, 3) if isinstance(prefill_tps, (int, float)) else None,
    "finish_reason": finish_reason,
    "response": content,
    "error": error,
    "metadata": metadata,
}
with open(output_path, "a", encoding="utf-8") as f:
    f.write(json.dumps(record, ensure_ascii=False) + "\n")
print(json.dumps(record, ensure_ascii=False))
if status != 200 or not content.strip():
    sys.exit(2)
PY

# Store a clean JSONL result set for this run.
: > "$OUT/results.jsonl"

wait_ready() {
  local name="$1" port="$2" pid="$3" log_file="$4"
  for _ in $(seq 1 90); do
    if curl -fsS --max-time 2 "http://127.0.0.1:${port}/v1/models" >/dev/null 2>&1; then
      log "$name listo en puerto $port"
      return 0
    fi
    if ! kill -0 "$pid" 2>/dev/null; then
      log "$name terminó durante el arranque; últimas líneas del log:"
      tail -60 "$log_file" || true
      return 1
    fi
    sleep 1
  done
  log "Tiempo de espera agotado para $name; últimas líneas del log:"
  tail -60 "$log_file" || true
  return 1
}

run_trials() {
  local engine="$1" url="$2" model="$3"
  local i
  # One unrecorded warm-up, then measured runs; identical prompt, max_tokens and sampling.
  log "$engine: calentamiento"
  python3 "$OUT/client.py" "$engine" "$url" "$model" "$PROMPT" "$MAX_TOKENS" 0 "$OUT/warmup.jsonl" || true
  for i in $(seq 1 "$RUNS"); do
    log "$engine: prueba $i/$RUNS"
    python3 "$OUT/client.py" "$engine" "$url" "$model" "$PROMPT" "$MAX_TOKENS" "$i" "$OUT/results.jsonl" || {
      log "$engine devolvió un error o una respuesta vacía; revisa sus logs."
    }
  done
}

log "Resultados en $OUT"
log "Nota: Mistral.rs, llama.cpp y RustingStrata usan GGUF Q4_K_M; TensorFold usa MLX-4bit."
nvidia-smi > "$OUT/nvidia-smi-before.txt" 2>&1 || true

# 1) Mistral.rs: first, then stop it before the next engine uses the GPU.
log "Arrancando Mistral.rs"
"$MISTRAL" serve -f "$GGUF" \
  --host 127.0.0.1 --port "$MISTRAL_PORT" \
  --max-model-len "$CTX" --max-seqs 1 --no-ui \
  >"$OUT/mistral-rs-server.log" 2>&1 &
pid=$!; PIDS+=("$pid")
wait_ready "Mistral.rs" "$MISTRAL_PORT" "$pid" "$OUT/mistral-rs-server.log" || exit 1
run_trials "mistral_rs" "http://127.0.0.1:${MISTRAL_PORT}/v1/chat/completions" "default"
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
PIDS=("${PIDS[@]/$pid}")
sleep 3

# 2) TensorFold: proven working reserve/context on this 4 GiB GPU.
log "Arrancando TensorFold (contexto $CTX, reserva 0.5 GiB)"
TENSORFOLD_MEMORY_RESERVE_GIB=0.5 \
TENSORFOLD_CUDA_MEMORY_LIMIT_GB=3.5 \
"$TF" serve "$TF_MODEL" \
  --backend cuda --host 127.0.0.1 --port "$TF_PORT" \
  --context "$CTX" --max-tokens "$MAX_TOKENS" \
  --no-thinking --no-drafts --no-update-check \
  >"$OUT/tensorfold-server.log" 2>&1 &
pid=$!; PIDS+=("$pid")
wait_ready "TensorFold" "$TF_PORT" "$pid" "$OUT/tensorfold-server.log" || exit 1
run_trials "tensorfold" "http://127.0.0.1:${TF_PORT}/v1/chat/completions" "$TF_MODEL"
kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true
PIDS=("${PIDS[@]/$pid}")
sleep 2

# 3) llama.cpp: turn off reasoning and disable prompt cache.
log "Arrancando llama.cpp CUDA"
"$LLAMA" \
  --model "$GGUF" \
  --host 127.0.0.1 --port "$LLAMA_PORT" \
  --ctx-size "$CTX" --n-predict "$MAX_TOKENS" \
  --n-gpu-layers 99 \
  --reasoning off --reasoning-format none \
  --chat-template-kwargs '{"enable_thinking":false}' \
  --no-cache-prompt \
  >"$OUT/llama-cpp-server.log" 2>&1 &
pid=$!; PIDS+=("$pid")
wait_ready "llama.cpp" "$LLAMA_PORT" "$pid" "$OUT/llama-cpp-server.log" || exit 1
run_trials "llama_cpp" "http://127.0.0.1:${LLAMA_PORT}/v1/chat/completions" "qwen3.5-4b-Q4_K_M.gguf"
kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true
PIDS=("${PIDS[@]/$pid}")
sleep 2

# 4) RustingStrata: same GGUF, GPU, context, prompt and output limit.
log "Arrancando RustingStrata"
NVRTC_DIR="$HOME/rusting-strata-test/vendor/nvrtc13/root/usr/local/cuda-13.0/targets/x86_64-linux/lib"
STRATA_CACHE="$HOME/rusting-strata-test/vendor/nvrtc13/cache-1300"
[[ -d "$NVRTC_DIR" ]] || fail "No encuentro el NVRTC CUDA 13.0 aislado: $NVRTC_DIR"
mkdir -p "$STRATA_CACHE"
LD_LIBRARY_PATH="$NVRTC_DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
XDG_CACHE_HOME="$STRATA_CACHE" \
"$STRATA" serve --model "$GGUF" --gpu --ctx "$CTX" --addr "127.0.0.1:${STRATA_PORT}" \
  >"$OUT/rusting-strata-server.log" 2>&1 &
pid=$!; PIDS+=("$pid")
wait_ready "RustingStrata" "$STRATA_PORT" "$pid" "$OUT/rusting-strata-server.log" || exit 1
run_trials "rusting_strata" "http://127.0.0.1:${STRATA_PORT}/v1/chat/completions" "qwen3.5-4b-Q4_K_M"
kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true
PIDS=("${PIDS[@]/$pid}")

nvidia-smi > "$OUT/nvidia-smi-after.txt" 2>&1 || true

python3 - "$OUT/results.jsonl" "$OUT/results.csv" "$OUT/summary.md" <<'PY'
import csv, json, statistics, sys
src, csv_path, md_path = sys.argv[1:]
rows = []
with open(src, encoding="utf-8") as f:
    for line in f:
        if line.strip():
            rows.append(json.loads(line))
fields = ["engine","run","http_status","wall_seconds","ttft_seconds","prompt_tokens",
          "completion_tokens","tokens_per_second","prefill_tokens_per_second",
          "finish_reason","response","error"]
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fields)
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k) for k in fields})

lines = [
    "# Qwen3.5-4B: benchmark de cuatro motores",
    "",
    "Pruebas secuenciales; misma pregunta, temperatura 0, máximo 32 tokens y contexto 256.",
    "Mistral.rs, llama.cpp y RustingStrata usan GGUF Q4_K_M; TensorFold usa MLX-4bit. La cuantización y la colocación GPU/CPU pueden diferir.",
    "La velocidad es la métrica del motor cuando está disponible; `wall_seconds` mide la petición completa.",
    "",
    "| Motor | Pruebas válidas | Mediana latencia (s) | Mediana generación (tok/s) | Mediana TTFT (s) |",
    "|---|---:|---:|---:|---:|",
]
for engine in ("mistral_rs", "tensorfold", "llama_cpp", "rusting_strata"):
    valid = [r for r in rows if r["engine"] == engine and r["http_status"] == 200 and r["response"].strip()]
    if not valid:
        lines.append(f"| {engine} | 0 | n/d | n/d | n/d |")
        continue
    walls = [r["wall_seconds"] for r in valid]
    tps = [r["tokens_per_second"] for r in valid if isinstance(r.get("tokens_per_second"), (int,float))]
    ttfts = [r["ttft_seconds"] for r in valid if isinstance(r.get("ttft_seconds"), (int,float))]
    lines.append("| {} | {} | {} | {} | {} |".format(
        engine, len(valid),
        f"{statistics.median(walls):.3f}",
        f"{statistics.median(tps):.2f}" if tps else "n/d",
        f"{statistics.median(ttfts):.3f}" if ttfts else "n/d"))
lines += ["", "## Respuestas y errores", ""]
for r in rows:
    lines.append(f"- **{r['engine']} #{r['run']}** (HTTP {r['http_status']}): {r['response'] or '(respuesta vacía)'}")
    if r.get("error"):
        lines.append(f"  - Error: {r['error']}")
lines += ["", "Los campos `n/d` significan que el servidor no proporcionó una métrica compatible; no se ha inventado ni estimado como dato medido.", ""]
with open(md_path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
print("\n".join(lines))
PY

log "Benchmark terminado."
log "CSV: $OUT/results.csv"
log "Resumen: $OUT/summary.md"
log "Logs: $OUT/"
